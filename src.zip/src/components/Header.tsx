import React from "react";
import {useState} from 'react';
import * as TbIcons from "react-icons/tb"
import TextField from "@mui/material/TextField";
import List from "./List";
import "../styles/Header.css"
import { IconContext } from 'react-icons/lib';
import logo from "../components/logohp.png";
import * as BiIcons from "react-icons/bi"


const Header = ()  => {
    
    const [searchInput, setSearchInput] = useState("");
    return(
		<div className="header">
			<h1 className="logo"><img src={logo} width="60px" height="30px" ></img>HPE Cray EX Console</h1>
			<div className="search">
        <TextField
          id="outlined-basic"
          variant="outlined"
          fullWidth
          label="Search            "
        />
        
        
      </div>
      <div className="icon"><IconContext.Provider value={{className: "top-react-icons" }}><BiIcons.BiSearchAlt/></IconContext.Provider></div>
		</div>
	
        /*
        <div className="headerheader">
           
                <span className="logo"><img src={logo} width="60px" height="30px" ></img></span>
                <span><h2>HPE Cray EX Concole</h2></span>
                
                <span className="extra">
                <span className="main">
      
      <div className="search">
        <TextField
          id="outlined-basic"
          variant="outlined"
          fullWidth
          label="Search            "
        />
      </div>
     
    </span>

                </span>
            
        </div>*/
    )

}

export default Header;