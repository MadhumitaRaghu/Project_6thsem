import { PrismLight as SyntaxHighlighter } from 'react-syntax-highlighter';
import * as style1 from 'react-syntax-highlighter/dist/esm/styles/prism';
import * as style2 from "react-syntax-highlighter/dist/esm/styles/hljs"
import {AiOutlineCheckCircle, AiFillPlayCircle} from 'react-icons/ai'
import * as FiIcons from "react-icons/fi"
import "../styles/Markdown.css"
import { useEffect, useState } from 'react';
import {GiBackwardTime} from "react-icons/gi"
import "../styles/Codenew.css"
import ReactMarkdown from "react-markdown"
import Markdown from "markdown-to-jsx";
import bash from 'react-syntax-highlighter/dist/cjs/languages/prism/bash'
import * as Suite from '@rsuite/icons';
import { color } from '@mui/system';
SyntaxHighlighter.registerLanguage('bash', bash)


const IconChange = [
  {
    title:'redcheck',
    icon: <AiOutlineCheckCircle color='red'></AiOutlineCheckCircle>
  },
  {
    title: 'greencheck',
    icon: <AiOutlineCheckCircle color='green'></AiOutlineCheckCircle>
  }
]
let countOL = 0;

function Texty(){
  const TextHead = ({ children }:any) => {
    return (
      <div className="h1">
        
        {children}
      </div>
    );
  };
  const TextHead2 = ({ children }:any) => {
    return (
      <div className="h2">
        {children}
      </div>
    );
  };
  const TextHead3 = ({ children }:any) => {
    return (
      <div className="h3">
        {children}
      </div>
    );
  };
}
const TextHead = ({ children }:any ) => {
  
  return (
    <div className="h1">
      
      {children}
    </div>
  );
  
};
const TextHead2 = ({ children }:any) => {
  return (
    <div className="h2">
      {children}
    </div>
  );
};
const TextHead3 = ({ children }:any) => {
  return (
    <div className="h3">
      {children}
    </div>
  );
};
const TextBlock = ({children }:any) => {
  
  countOL = countOL+1;
  return(
   <div className="everything">
    <AiOutlineCheckCircle color='red'/>
    <li>{children}</li>
    </div>
  )
  
  
}
const displayTime = ()=>{
  return(
    <div style={{lineHeight:"3.5"}}><GiBackwardTime style={{fontSize: '1.3rem', color:"darkgoldenrod", fontWeight:"bold" }}></GiBackwardTime></div>
  )
}
const CodeBlock = ({className, children}:any) => {
  let lang = 'bash';
  const [isActive, setIsActive] = useState(false);
 
  
  return (
    <>
    
    <div className='codepart'>
    <div style={{marginTop: '1%', marginRight: '3%'}}>
    
    <div style={{lineHeight:"3.5"}}><GiBackwardTime style={{fontSize: '1.4rem', color:"darkgoldenrod", fontWeight:"bold" }}></GiBackwardTime></div>
    </div>
    
    <SyntaxHighlighter language={lang} style={style1.coy }>
      
      {children}
    </SyntaxHighlighter>
    
  
    </div></>
  )
}

const PreBlock = ({children, ...rest}:any) => {
  if (children ['type'] === 'code') {
    
    return(
     
      CodeBlock(children['props'])
      
    );
  }
  
  return( 
  
  <pre {...rest}>{children}</pre>
  );
}


interface PostProps{
  content:any
}
const Code2 = ({content}:any) => {
  const [postContent, setPostContent] = useState("");
console.log(postContent)
  useEffect(() => {
    const set=async()=>{
      let a=await fetch(content)
      console.log(a)
      let d=await a.text();
      setPostContent(d);

    }
    set();

  }, [])
  
  return (
    <>
    <div className='markdown'>
    
    <Markdown options={{
            overrides: {
             pre: PreBlock,
            
          
              li: TextBlock,
            
            h1:TextHead,
            h2:TextHead2,
            h3:TextHead3
        
            },
          }}>{postContent}</Markdown></div>
    </>
  )
}


  

export default Code2