import React from 'react'

const Overview = () => {
  return (
    <div className='pages'>overview</div>
  )
}

export default Overview