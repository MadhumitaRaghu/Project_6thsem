import React from 'react'

const Users = () => {
  return (
    <div className='pages'>Users</div>
  )
}

export default Users