import React from 'react'

const Revenue = () => {
  return (
    <div className='pages'>Revenue</div>
  )
}

export default Revenue